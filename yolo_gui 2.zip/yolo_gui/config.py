# Configuration file for YOLOv8 Object Detection GUI
# This separates configuration from the main application logic

import os
from typing import Dict, Tuple

# API Configuration
API_BASE_URL = "http://127.0.0.1:8000"
API_PREDICT_ENDPOINT = f"{API_BASE_URL}/predict"
API_HEALTH_ENDPOINT = f"{API_BASE_URL}/health"  # For health checks
API_TIMEOUT = 30  # seconds

# Model Configuration
MODEL_PATH = "output hackwithindia/detection_runs/baseline_run/weights/best.pt"
MODEL_INPUT_SIZE = (640, 640)  # Standard YOLOv8 input size
CONFIDENCE_THRESHOLD = 0.25  # Minimum confidence for detections
IOU_THRESHOLD = 0.45  # IoU threshold for NMS

# Class Configuration
CLASS_NAMES: Dict[int, str] = {
    0: "Fire Extinguisher",
    1: "ToolBox", 
    2: "Oxygen Tank"
}

# Color Configuration (RGB format)
CLASS_COLORS: Dict[int, Tuple[int, int, int]] = {
    0: (255, 0, 0),    # Red for Fire Extinguisher
    1: (0, 255, 0),    # Green for ToolBox
    2: (0, 0, 255)     # Blue for Oxygen Tank
}

# UI Configuration
MAX_IMAGE_SIZE = (1024, 1024)  # Maximum display size
SUPPORTED_FORMATS = ["jpg", "jpeg", "png", "bmp", "tiff"]
MAX_FILE_SIZE_MB = 10  # Maximum upload file size

# Logging Configuration
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Performance Configuration
MAX_CONCURRENT_REQUESTS = 5
CACHE_SIZE = 100  # Number of results to cache

# Development Configuration
DEBUG_MODE = os.getenv("DEBUG", "False").lower() == "true"
SHOW_PERFORMANCE_METRICS = DEBUG_MODE