# YOLOv8 Object Detection GUI

A simple Streamlit web interface for YOLOv8 object detection in space station interiors.

## 🚀 Features

- Upload images (JPEG/PNG)
- Real-time object detection using YOLOv8
- Visual bounding boxes with confidence scores
- Detects: Fire Extinguisher, ToolBox, Oxygen Tank
- Clean, intuitive web interface

## 📋 Prerequisites

1. **FastAPI Backend**: Make sure your FastAPI backend is running with the YOLOv8 model
2. **Python 3.8+**: Required for Streamlit and dependencies

## 🛠️ Installation

1. **Clone or download this project**

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

## 🚀 Running the Application

### Step 1: Start the FastAPI Backend
Make sure your FastAPI server is running on `http://127.0.0.1:8000`:
```bash
uvicorn main:app --reload
```

### Step 2: Start the Streamlit GUI
```bash
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`

## 📱 How to Use

1. **Upload Image**: Click "Browse files" and select a JPEG/PNG image
2. **Detect Objects**: Click the "🔍 Detect Objects" button
3. **View Results**: See the annotated image with bounding boxes and detection details

## 🎯 Supported Objects

- 🧯 **Fire Extinguisher** (Red boxes)
- 🧰 **ToolBox** (Green boxes)
- 🫧 **Oxygen Tank** (Blue boxes)

## 🔧 Configuration

- **API Endpoint**: Modify `API_URL` in `app.py` if your FastAPI runs on a different address
- **Class Names**: Update `CLASS_NAMES` dictionary to match your model's classes
- **Colors**: Customize bounding box colors in the `COLORS` dictionary

## 🐛 Troubleshooting

### "Cannot connect to FastAPI backend"
- Ensure FastAPI server is running on `http://127.0.0.1:8000`
- Check if the `/predict` endpoint is available
- Use the "Test API Connection" button in the sidebar

### "No objects detected"
- Try images with clearer objects
- Ensure the image contains space station interior objects
- Check if the model is properly loaded in the backend

## 📁 Project Structure

```
yolo_gui/
├── app.py              # Main Streamlit application
├── app_enhanced.py     # Enhanced version with better error handling
├── config.py           # Configuration file for better maintainability
├── requirements.txt    # Python dependencies
└── README.md          # This file
```

## 🎯 Model Configuration

The application is configured to use the YOLOv8 model located at:
```
output hackwithindia/detection_runs/baseline_run/weights/best.pt
```

This model is specifically trained for detecting:
- 🧯 Fire Extinguisher
- 🧰 ToolBox  
- 🫁 Oxygen Tank

You can modify the model path in `config.py` or directly in `app.py` if needed.

## 🚀 Enhanced Version

For better code quality and maintainability, use `app_enhanced.py` which includes:

### ✨ Features
- **Modular Configuration**: Centralized settings in `config.py`
- **Enhanced Error Handling**: Better API connection management
- **Logging System**: Comprehensive logging for debugging
- **Input Validation**: File size and format validation
- **Performance Metrics**: Detection timing and statistics
- **API Health Checks**: Monitor backend connectivity
- **Session History**: Track detection results
- **Improved UI**: Better styling and user experience
- **Code Organization**: Object-oriented design with proper separation of concerns

### 🔧 Usage
```bash
streamlit run app_enhanced.py
```

### 🎛️ Configuration Options
Edit `config.py` to customize:
- API endpoints and timeouts
- Model paths and parameters
- UI settings and thresholds
- Logging configuration
- Performance settings

## 🏆 Hackathon Demo Tips

1. **Test the connection** before presenting using the sidebar button
2. **Prepare sample images** of space station interiors with the target objects
3. **Show the detection details** section to highlight confidence scores
4. **Demonstrate real-time detection** by uploading different images

---

**Built for YOLOv8 Object Detection Hackathon** 🚀