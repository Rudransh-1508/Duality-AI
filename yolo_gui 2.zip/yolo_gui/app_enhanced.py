import streamlit as st
import requests
import json
from PIL import Image, ImageDraw, ImageFont
import io
import cv2
import numpy as np
import logging
import time
from typing import Optional, List, Dict, Any
from pathlib import Path

# Import configuration
from config import (
    API_PREDICT_ENDPOINT, API_HEALTH_ENDPOINT, API_TIMEOUT,
    MODEL_PATH, CLASS_NAMES, CLASS_COLORS, MAX_IMAGE_SIZE,
    SUPPORTED_FORMATS, MAX_FILE_SIZE_MB, LOG_LEVEL, LOG_FORMAT,
    CONFIDENCE_THRESHOLD, SHOW_PERFORMANCE_METRICS
)

# Configure logging
logging.basicConfig(level=getattr(logging, LOG_LEVEL), format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="YOLOv8 Object Detection",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
.main-header {
    font-size: 2.5rem;
    color: #1f77b4;
    text-align: center;
    margin-bottom: 1rem;
}
.detection-box {
    border: 2px solid #1f77b4;
    border-radius: 10px;
    padding: 1rem;
    margin: 0.5rem 0;
    background-color: #f8f9fa;
}
.metric-container {
    display: flex;
    justify-content: space-around;
    margin: 1rem 0;
}
</style>
""", unsafe_allow_html=True)

class YOLODetectionApp:
    """Main application class for YOLOv8 object detection GUI"""
    
    def __init__(self):
        self.session_state_init()
        
    def session_state_init(self):
        """Initialize session state variables"""
        if 'detection_history' not in st.session_state:
            st.session_state.detection_history = []
        if 'api_status' not in st.session_state:
            st.session_state.api_status = None
            
    def validate_image(self, uploaded_file) -> bool:
        """Validate uploaded image file"""
        if uploaded_file is None:
            return False
            
        # Check file size
        if uploaded_file.size > MAX_FILE_SIZE_MB * 1024 * 1024:
            st.error(f"File size exceeds {MAX_FILE_SIZE_MB}MB limit")
            return False
            
        # Check file format
        file_extension = uploaded_file.name.split('.')[-1].lower()
        if file_extension not in SUPPORTED_FORMATS:
            st.error(f"Unsupported format. Please use: {', '.join(SUPPORTED_FORMATS)}")
            return False
            
        return True
        
    def resize_image_if_needed(self, image: Image.Image) -> Image.Image:
        """Resize image if it exceeds maximum display size"""
        if image.size[0] > MAX_IMAGE_SIZE[0] or image.size[1] > MAX_IMAGE_SIZE[1]:
            image.thumbnail(MAX_IMAGE_SIZE, Image.Resampling.LANCZOS)
            logger.info(f"Image resized to {image.size}")
        return image
        
    def check_api_health(self) -> bool:
        """Check if the API is healthy and responsive"""
        try:
            response = requests.get(API_HEALTH_ENDPOINT, timeout=5)
            return response.status_code == 200
        except:
            try:
                # Fallback: try the predict endpoint with a simple GET
                response = requests.get(API_PREDICT_ENDPOINT.replace('/predict', '/'), timeout=5)
                return response.status_code in [200, 405]  # 405 is OK for GET on POST endpoint
            except:
                return False
                
    def draw_bounding_boxes(self, image: Image.Image, detections: List[Dict]) -> Image.Image:
        """Draw bounding boxes with enhanced styling"""
        img_array = np.array(image)
        img_cv2 = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        height, width = img_cv2.shape[:2]
        
        for detection in detections:
            bbox = detection['bbox']
            confidence = detection['confidence']
            class_id = detection['class_id']
            
            # Skip low confidence detections
            if confidence < CONFIDENCE_THRESHOLD:
                continue
                
            # Convert coordinates
            x1, y1, x2, y2 = bbox
            if all(coord <= 1.0 for coord in bbox):
                x1, y1, x2, y2 = int(x1 * width), int(y1 * height), int(x2 * width), int(y2 * height)
            else:
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            
            # Get styling
            class_name = CLASS_NAMES.get(class_id, f"Class {class_id}")
            color = CLASS_COLORS.get(class_id, (255, 255, 255))
            
            # Draw enhanced bounding box
            thickness = max(2, int(min(width, height) / 300))
            cv2.rectangle(img_cv2, (x1, y1), (x2, y2), color, thickness)
            
            # Draw corner markers for better visibility
            corner_length = 20
            cv2.line(img_cv2, (x1, y1), (x1 + corner_length, y1), color, thickness + 1)
            cv2.line(img_cv2, (x1, y1), (x1, y1 + corner_length), color, thickness + 1)
            cv2.line(img_cv2, (x2, y2), (x2 - corner_length, y2), color, thickness + 1)
            cv2.line(img_cv2, (x2, y2), (x2, y2 - corner_length), color, thickness + 1)
            
            # Enhanced label
            label = f"{class_name}: {confidence:.1%}"
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = max(0.5, min(width, height) / 1000)
            label_thickness = max(1, thickness - 1)
            
            (text_width, text_height), baseline = cv2.getTextSize(label, font, font_scale, label_thickness)
            
            # Draw label background with padding
            padding = 5
            cv2.rectangle(img_cv2, 
                         (x1, y1 - text_height - 2 * padding), 
                         (x1 + text_width + 2 * padding, y1), 
                         color, -1)
            
            # Draw text
            cv2.putText(img_cv2, label, 
                       (x1 + padding, y1 - padding), 
                       font, font_scale, (255, 255, 255), label_thickness)
        
        img_rgb = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2RGB)
        return Image.fromarray(img_rgb)
        
    def make_prediction(self, image_file) -> Optional[Dict[str, Any]]:
        """Make prediction with enhanced error handling and timing"""
        start_time = time.time()
        
        try:
            files = {"file": ("image.jpg", image_file, "image/jpeg")}
            
            with st.spinner("🤖 Running YOLOv8 detection..."):
                response = requests.post(API_PREDICT_ENDPOINT, files=files, timeout=API_TIMEOUT)
            
            prediction_time = time.time() - start_time
            
            if response.status_code == 200:
                result = response.json()
                result['prediction_time'] = prediction_time
                logger.info(f"Prediction completed in {prediction_time:.2f}s")
                return result
            else:
                st.error(f"API Error: {response.status_code} - {response.text}")
                logger.error(f"API error: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.ConnectionError:
            st.error("❌ Cannot connect to the FastAPI backend. Please check if the server is running.")
            logger.error("Connection error to FastAPI backend")
            return None
        except requests.exceptions.Timeout:
            st.error(f"❌ Request timed out after {API_TIMEOUT} seconds.")
            logger.error(f"Request timeout after {API_TIMEOUT}s")
            return None
        except Exception as e:
            st.error(f"❌ Unexpected error: {str(e)}")
            logger.error(f"Unexpected error: {str(e)}")
            return None
            
    def display_detection_metrics(self, detections: List[Dict], prediction_time: float):
        """Display detection metrics and statistics"""
        if not SHOW_PERFORMANCE_METRICS:
            return
            
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Objects Detected", len(detections))
        with col2:
            st.metric("Prediction Time", f"{prediction_time:.2f}s")
        with col3:
            avg_confidence = np.mean([d['confidence'] for d in detections]) if detections else 0
            st.metric("Avg Confidence", f"{avg_confidence:.1%}")
        with col4:
            max_confidence = max([d['confidence'] for d in detections]) if detections else 0
            st.metric("Max Confidence", f"{max_confidence:.1%}")
            
    def render_sidebar(self):
        """Render enhanced sidebar with status and controls"""
        with st.sidebar:
            st.header("ℹ️ Model Information")
            st.write(f"**Model:** YOLOv8")
            st.write(f"**Path:** `{MODEL_PATH}`")
            st.write(f"**Classes:** {len(CLASS_NAMES)}")
            
            # Display class information
            st.subheader("🎯 Detectable Objects")
            for class_id, class_name in CLASS_NAMES.items():
                color = CLASS_COLORS[class_id]
                st.write(f"🔸 **{class_name}** (RGB: {color})")
            
            st.header("🔧 Configuration")
            st.write(f"**API Endpoint:** `{API_PREDICT_ENDPOINT}`")
            st.write(f"**Confidence Threshold:** {CONFIDENCE_THRESHOLD}")
            st.write(f"**Max File Size:** {MAX_FILE_SIZE_MB}MB")
            
            # API Health Check
            st.header("🔗 API Status")
            if st.button("Check API Health", type="secondary"):
                with st.spinner("Checking API..."):
                    is_healthy = self.check_api_health()
                    st.session_state.api_status = is_healthy
                    
            if st.session_state.api_status is not None:
                if st.session_state.api_status:
                    st.success("✅ API is healthy")
                else:
                    st.error("❌ API is not responding")
                    
            # Detection History
            if st.session_state.detection_history:
                st.header("📊 Session Statistics")
                total_detections = sum(len(h['detections']) for h in st.session_state.detection_history)
                st.write(f"**Images Processed:** {len(st.session_state.detection_history)}")
                st.write(f"**Total Detections:** {total_detections}")
                
                if st.button("Clear History"):
                    st.session_state.detection_history = []
                    st.rerun()
                    
    def run(self):
        """Main application runner"""
        # Header
        st.markdown('<h1 class="main-header">🚀 YOLOv8 Object Detection for Space Station</h1>', 
                   unsafe_allow_html=True)
        
        st.markdown("""
        ### 📋 Instructions:
        Upload an image of the space station interior to detect **Fire Extinguisher**, **ToolBox**, **Oxygen Tank** 
        using our trained YOLOv8 model.
        
        **How to use:**
        1. 📤 Upload an image (JPEG/PNG, max 10MB)
        2. 🔍 Click "Detect Objects" 
        3. 📊 View results with bounding boxes and confidence scores
        """)
        
        # Render sidebar
        self.render_sidebar()
        
        st.markdown("---")
        
        # File uploader with validation
        uploaded_file = st.file_uploader(
            "Choose an image file",
            type=SUPPORTED_FORMATS,
            help=f"Upload a {', '.join(SUPPORTED_FORMATS).upper()} image (max {MAX_FILE_SIZE_MB}MB)"
        )
        
        if uploaded_file is not None and self.validate_image(uploaded_file):
            # Load and display image
            image = Image.open(uploaded_file)
            image = self.resize_image_if_needed(image)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📤 Uploaded Image")
                st.image(image, caption=f"Original Image ({image.size[0]}x{image.size[1]})", 
                        use_column_width=True)
            
            # Detection button
            if st.button("🔍 Detect Objects", type="primary", use_container_width=True):
                uploaded_file.seek(0)
                result = self.make_prediction(uploaded_file)
                
                if result is not None:
                    detections = result.get('detections', [])
                    prediction_time = result.get('prediction_time', 0)
                    
                    # Store in history
                    st.session_state.detection_history.append({
                        'timestamp': time.time(),
                        'detections': detections,
                        'prediction_time': prediction_time
                    })
                    
                    if detections:
                        # Draw and display results
                        annotated_image = self.draw_bounding_boxes(image, detections)
                        
                        with col2:
                            st.subheader("🎯 Detection Results")
                            st.image(annotated_image, caption=f"Detected {len(detections)} objects", 
                                   use_column_width=True)
                        
                        # Display metrics
                        self.display_detection_metrics(detections, prediction_time)
                        
                        # Detection details
                        st.subheader("📊 Detection Details")
                        
                        for i, detection in enumerate(detections):
                            class_id = detection['class_id']
                            class_name = CLASS_NAMES.get(class_id, f"Class {class_id}")
                            confidence = detection['confidence']
                            bbox = detection['bbox']
                            
                            with st.container():
                                st.markdown(f"""
                                <div class="detection-box">
                                    <h4>🎯 Detection {i+1}: {class_name}</h4>
                                    <p><strong>Confidence:</strong> {confidence:.1%}</p>
                                    <p><strong>Bounding Box:</strong> {bbox}</p>
                                </div>
                                """, unsafe_allow_html=True)
                    else:
                        with col2:
                            st.subheader("🎯 Detection Results")
                            st.info("No objects detected in the image.")
                            st.image(image, caption="No detections found", use_column_width=True)
        
        # Footer
        st.markdown("---")
        st.markdown(f"""
        **💡 Tips for better results:**
        - Use clear, well-lit images
        - Ensure objects are clearly visible
        - Avoid heavily cropped images
        
        **🔧 Technical Details:**
        - Model: YOLOv8 (`{MODEL_PATH}`)
        - Confidence threshold: {CONFIDENCE_THRESHOLD}
        - Supported formats: {', '.join(SUPPORTED_FORMATS).upper()}
        """)

if __name__ == "__main__":
    app = YOLODetectionApp()
    app.run()