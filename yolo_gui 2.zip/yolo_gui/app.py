import streamlit as st
import requests
import json
from PIL import Image, ImageDraw, ImageFont
import io
import cv2
import numpy as np

# Page configuration
st.set_page_config(
    page_title="YOLOv8 Object Detection",
    page_icon="🚀",
    layout="wide"
)

# Title and instructions
st.title("🚀 YOLOv8 Object Detection for Space Station")
st.markdown("""
### Instructions:
Upload an image of the space station interior to detect **Fire Extinguisher**, **ToolBox**, **Oxygen Tank** using our trained YOLOv8 model.

**How to use:**
1. Upload an image (JPEG/PNG)
2. Click the "Detect Objects" button
3. View the results with bounding boxes and confidence scores
""")

# API endpoint and model configuration
API_URL = "http://127.0.0.1:8000/predict"
MODEL_PATH = "output hackwithindia/detection_runs/baseline_run/weights/best.pt"

# Class names mapping (adjust based on your model)
CLASS_NAMES = {
    0: "Fire Extinguisher",
    1: "ToolBox", 
    2: "Oxygen Tank"
}

# Color mapping for different classes
COLORS = {
    0: (255, 0, 0),    # Red for Fire Extinguisher
    1: (0, 255, 0),    # Green for ToolBox
    2: (0, 0, 255)     # Blue for Oxygen Tank
}

def draw_bounding_boxes(image, detections):
    """
    Draw bounding boxes on the image with class names and confidence scores
    """
    # Convert PIL image to numpy array for OpenCV
    img_array = np.array(image)
    img_cv2 = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
    
    # Get image dimensions
    height, width = img_cv2.shape[:2]
    
    for detection in detections:
        # Extract detection data
        bbox = detection['bbox']  # [x1, y1, x2, y2]
        confidence = detection['confidence']
        class_id = detection['class_id']
        
        # Convert normalized coordinates to pixel coordinates if needed
        x1, y1, x2, y2 = bbox
        if all(coord <= 1.0 for coord in bbox):  # If normalized
            x1 = int(x1 * width)
            y1 = int(y1 * height)
            x2 = int(x2 * width)
            y2 = int(y2 * height)
        else:  # If already in pixel coordinates
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
        
        # Get class name and color
        class_name = CLASS_NAMES.get(class_id, f"Class {class_id}")
        color = COLORS.get(class_id, (255, 255, 255))
        
        # Draw bounding box
        cv2.rectangle(img_cv2, (x1, y1), (x2, y2), color, 2)
        
        # Prepare label text
        label = f"{class_name}: {confidence:.2f}"
        
        # Calculate text size and background rectangle
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.6
        thickness = 2
        (text_width, text_height), baseline = cv2.getTextSize(label, font, font_scale, thickness)
        
        # Draw background rectangle for text
        cv2.rectangle(img_cv2, (x1, y1 - text_height - 10), (x1 + text_width, y1), color, -1)
        
        # Draw text
        cv2.putText(img_cv2, label, (x1, y1 - 5), font, font_scale, (255, 255, 255), thickness)
    
    # Convert back to PIL Image
    img_rgb = cv2.cvtColor(img_cv2, cv2.COLOR_BGR2RGB)
    return Image.fromarray(img_rgb)

def make_prediction(image_file):
    """
    Send image to FastAPI backend for prediction
    """
    try:
        # Prepare the file for upload
        files = {"file": ("image.jpg", image_file, "image/jpeg")}
        
        # Make POST request to FastAPI
        response = requests.post(API_URL, files=files, timeout=30)
        
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"API Error: {response.status_code} - {response.text}")
            return None
            
    except requests.exceptions.ConnectionError:
        st.error("❌ Cannot connect to the FastAPI backend. Please make sure the server is running at http://127.0.0.1:8000")
        return None
    except requests.exceptions.Timeout:
        st.error("❌ Request timed out. The server might be busy.")
        return None
    except Exception as e:
        st.error(f"❌ An error occurred: {str(e)}")
        return None

# Main app interface
st.markdown("---")

# File uploader
uploaded_file = st.file_uploader(
    "Choose an image file",
    type=["jpg", "jpeg", "png"],
    help="Upload a JPEG or PNG image of space station interior"
)

if uploaded_file is not None:
    # Display uploaded image
    image = Image.open(uploaded_file)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📤 Uploaded Image")
        st.image(image, caption="Original Image", use_column_width=True)
    
    # Detect button
    if st.button("🔍 Detect Objects", type="primary"):
        with st.spinner("🤖 Running YOLOv8 detection..."):
            # Reset file pointer
            uploaded_file.seek(0)
            
            # Make prediction
            result = make_prediction(uploaded_file)
            
            if result is not None:
                # Check if detections were found
                detections = result.get('detections', [])
                
                if detections:
                    # Draw bounding boxes
                    annotated_image = draw_bounding_boxes(image, detections)
                    
                    with col2:
                        st.subheader("🎯 Detection Results")
                        st.image(annotated_image, caption="Detected Objects", use_column_width=True)
                    
                    # Display detection details
                    st.subheader("📊 Detection Details")
                    
                    for i, detection in enumerate(detections):
                        class_id = detection['class_id']
                        class_name = CLASS_NAMES.get(class_id, f"Class {class_id}")
                        confidence = detection['confidence']
                        bbox = detection['bbox']
                        
                        st.write(f"**Detection {i+1}:**")
                        st.write(f"- Object: {class_name}")
                        st.write(f"- Confidence: {confidence:.2%}")
                        st.write(f"- Bounding Box: {bbox}")
                        st.write("---")
                        
                else:
                    with col2:
                        st.subheader("🎯 Detection Results")
                        st.info("No objects detected in the image.")
                        st.image(image, caption="No detections found", use_column_width=True)

# Footer
st.markdown("---")
st.markdown(f"""
**Note:** Make sure your FastAPI backend is running on `http://127.0.0.1:8000` before using this app.

**Model Configuration:**
- Using YOLOv8 model: `{MODEL_PATH}`
- Trained for space station interior object detection

To start the backend, run:
```bash
uvicorn main:app --reload
```
""")

# Sidebar with additional info
with st.sidebar:
    st.header("ℹ️ About")
    st.write("""
    This app uses a trained YOLOv8 model to detect:
    - 🧯 Fire Extinguisher
    - 🧰 ToolBox  
    - 🫧 Oxygen Tank
    
    The model was specifically trained for space station interior object detection.
    """)
    
    st.header("🔧 Settings")
    st.write(f"**API Endpoint:** {API_URL}")
    st.write(f"**Model Path:** {MODEL_PATH}")
    
    # Add a test connection button
    if st.button("🔗 Test API Connection"):
        try:
            response = requests.get(API_URL.replace('/predict', '/'), timeout=5)
            if response.status_code == 200:
                st.success("✅ API is reachable!")
            else:
                st.warning(f"⚠️ API responded with status {response.status_code}")
        except:
            st.error("❌ Cannot reach API. Make sure FastAPI server is running.")